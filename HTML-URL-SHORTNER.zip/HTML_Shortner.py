from colored import fg, attr
from colorama import Fore, Style
import os, time, datetime, subprocess, asyncio
class colors:

    red = fg('#ff004d8')
    reset = attr('reset')
    gray = fg('#ff4b00')

print(f"""


{Fore.RED}                _    _ _  _ _  _    ____ _  _ ____ ____ ___ _  _ ____ ____ {Fore.RESET}
                |    | |\ | |_/     [__  |__| |  | |__/  |  |\ | |___ |__/ 
                |___ | | \| | \_    ___] |  | |__| |  \  |  | \| |___ |  \ 
                                                           


                        ═══════════════════════════════════
                  ═══════════════════════════════════════════════
{Fore.RED}                                   Made By Tana {Fore.RESET}




    """)

try:
    url_input = input(f"{Fore.RED}[{Fore.RESET}{Fore.WHITE}!{Fore.RESET}{Fore.RED}]{Fore.RESET} url to shorten: ")
    if url_input.startswith("https://" or "http://"):
        pass
    else:
        url_input = "https://" + url_input
    user_input = input(f"{Fore.RED}[{Fore.RESET}{Fore.WHITE}!{Fore.RESET}{Fore.RED}]{Fore.RESET} Enter a word (this word will be you shortner name): ")
    Size = int(input(f"{Fore.RED}[{Fore.RESET}{Fore.WHITE}!{Fore.RESET}{Fore.RED}]{Fore.RESET} size of your url\n{Fore.RED}[{Fore.RESET}{Fore.WHITE}!{Fore.RESET}{Fore.RED}]{Fore.RESET} Options are 1-6. 1 is the largest and 6 is the smallest: "))
    if Size in range(1, 7):
        html = f"<a href=\"{url_input}\"><h{Size}>{user_input}</h{Size}></a>"
        html_file = open("tanaluvsyou.html", "w")
        html_file.write(html)
        html_file.close()
    else:
        print(f"{Fore.RED}[{Fore.RESET}{Fore.WHITE}!{Fore.RESET}{Fore.RED}]{Fore.RESET} Invalid option")
except ValueError:
    print(f"{Fore.RED}[{Fore.RESET}{Fore.WHITE}!{Fore.RESET}{Fore.RED}]{Fore.RESET} You have entered a string not a number")

#dont skid or gay
